# Launch Readiness Checklist

Use this before treating a Sherpa integration as customer-ready.

Studio now surfaces this same rollout view directly through:
- `Launch actions`
- `Launch checklist`
- `Publish gate`
- `Support snapshot`

## 1. Host contract

- `demoContext` is scoped correctly
- `currentUser` is passed when shared sync is enabled
- route notes exist for the main demo routes
- `ttsEndpoint` is valid if AI voice is expected
- `catalogApiBaseUrl` is valid if shared catalog is expected

## 2. Deployment mode

- the intended deployment mode is explicit
- local/staging/production all use the same expected mode
- the team knows whether the host is:
  - browser-local
  - voice-enabled local
  - shared catalog
  - service-backed

## 3. Authoring reliability

- record first step
- pause
- add next step
- continue recording
- stop
- replay successfully

- restart-step flow verified
- source language confirmation verified
- transcript regeneration verified
- original voice vs AI voice verified

## 4. Publishing readiness

- journey health summary shows no blocking attention items
- replay reliability reviewed
- route context or step overrides exist where needed
- recovery snapshots work as expected

## 5. Shared sync

- local draft state is understandable
- sync completes successfully when shared catalog is enabled
- sync failure messaging is actionable
- remote synced state is visible after publish/save
- the last shared snapshot can still be restored if the shared API is temporarily unavailable

## 6. Presenter quality

- player shows the correct language and voice mode
- notes panel is coherent across key routes
- detached/manual exploration pause and resume behavior is verified
- assistant and studio branding assets render correctly

## 7. Operator readiness

- readiness summary can be exported
- support snapshot can be exported for rollout/support handoff
- service profile is visible in Studio and matches the intended deployment mode
- diagnostics are understandable to the host team
- the host integration guide is linked in project docs
- the team knows who owns TTS, transcription, and shared catalog operations
- publish gate is understood as the final go/no-go signal before launch
