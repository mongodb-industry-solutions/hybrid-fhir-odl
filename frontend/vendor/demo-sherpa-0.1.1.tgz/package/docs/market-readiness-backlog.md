# Demo Sherpa Market Readiness Backlog

## Purpose

Translate the roadmap into implementation slices that can be shipped as focused PRs.

This backlog excludes permissions/auth work.

## Phase 1 Backlog

### Epic 1: Source Recording and Voice Model

#### Slice 1.1

Goal:

- keep one explicit `sourceRecording`
- keep explicit `playbackVariants`
- make player and Studio use `Original voice` vs `AI voice`

Status:

- partially implemented

Files already involved:

- `src/modules/storage.js`
- `src/modules/StudioWorkbench.js`
- `src/components/DemoJourneyGuide.js`
- `tests/sherpaConfig.test.mjs`

Next acceptance criteria:

- no remaining UI label uses legacy mental models such as step-level “TTS” without voice identity
- derived language removal cleans all related data paths

#### Slice 1.2

Goal:

- require source language confirmation before first recording
- keep a default suggestion
- prevent silent language auto-assumptions

Status:

- in progress

Acceptance criteria:

- first recording confirms source language
- changing source language is a deliberate action
- source language is not “deleted” via planned-language controls

#### Slice 1.3

Goal:

- pass source language into transcription requests
- make host/backend honor it instead of auto-detecting by default

Files:

- `src/modules/StudioWorkbench.js`
- host backend `POST /api/journey/transcribe`
- docs

Acceptance criteria:

- English source recording stays English unless user changes source language
- transcript language mismatch is surfaced explicitly

### Epic 2: Recording Workflow Reliability

#### Slice 2.1

Goal:

- formalize per-step recording timeline resets
- fix pause -> add step -> continue flow

Status:

- partially implemented

Files:

- `src/modules/StudioWorkbench.js`
- `src/modules/storage.js`
- `tests/narrationSegments.test.mjs`

Acceptance criteria:

- no leading silence inherited across steps
- step 2 playback begins from its own actual start

#### Slice 2.2

Goal:

- improve recorder UX copy and actions

Tasks:

- rename recorder buttons and labels
- make “continue” explicit
- make paused-state messaging less ambiguous

Acceptance criteria:

- recorder actions are self-explanatory

#### Slice 2.3

Goal:

- add recorder E2E coverage

Scenarios:

- record first step
- pause/resume
- add step and continue
- restart step

Acceptance criteria:

- these flows are automated and stable

### Epic 3: Studio Workflow Simplification

#### Slice 3.1

Goal:

- introduce higher-level author workflow tabs:
  - `Record`
  - `Script`
  - `Voices`
  - `Review`

Approach:

- keep existing step internals behind the new grouping first
- do not remove advanced controls immediately

Acceptance criteria:

- the primary author path no longer depends on understanding all current tabs

#### Slice 3.2

Goal:

- simplify language management

Tasks:

- separate source language from derived languages
- improve derived language creation/removal
- make AI voice generation status easier to understand

Acceptance criteria:

- a user can tell what is source vs derived at a glance

### Epic 4: Playback Clarity

#### Slice 4.1

Goal:

- make the player’s active narration identity obvious

Tasks:

- surface `Original voice` vs `AI voice`
- show notes source and language more clearly
- polish paused/recovery states

Acceptance criteria:

- presenters always know what they are hearing and why playback paused

## Phase 2 Backlog

### Epic 5: Sherpa Service Mode

#### Slice 5.1

Goal:

- define a Sherpa-native service contract for transcription and TTS

Tasks:

- document the service contract
- support explicit transcribe and TTS endpoint resolution
- add runtime diagnostics when endpoints are missing or incompatible

Acceptance criteria:

- one host integration path works consistently

#### Slice 5.2

Goal:

- make Sherpa-hosted mode the preferred path

Tasks:

- move ASR/TTS assumptions out of arbitrary host routes
- add a small capability handshake

Acceptance criteria:

- host apps can integrate without custom AI endpoint implementations

### Epic 6: Architecture Split

#### Slice 6.1

Goal:

- extract recording session logic from `StudioWorkbench`

Target modules:

- `recordingSessionController`
- `transcriptionCoordinator`
- `stepCaptureTimeline`

Acceptance criteria:

- recording logic no longer lives inside the main Studio render module

#### Slice 6.2

Goal:

- extract playback state machine from `DemoJourneyGuide`

Target modules:

- `playbackStateMachine`
- `voiceSourceResolver`
- `checkpointRecovery`

Acceptance criteria:

- playback runtime logic is testable without the full player shell

#### Slice 6.3

Goal:

- isolate remote sync and local draft persistence

Acceptance criteria:

- sync logic can evolve without destabilizing core authoring UI

### Epic 7: Remote-First Drafts

#### Slice 7.1

Goal:

- add explicit local draft vs remote canonical model

Tasks:

- define sync states
- add draft recovery affordances
- preserve offline resilience

Acceptance criteria:

- browser-local state is no longer the only operational truth

## Phase 3 Backlog

### Epic 8: UX and Visual Polish

#### Slice 8.1

Goal:

- improve Studio visual hierarchy

Tasks:

- reduce control density
- improve section headers and status chips
- align copy across authoring surfaces

Acceptance criteria:

- Studio feels intentional and product-grade

#### Slice 8.2

Goal:

- improve player live-presenter ergonomics

Tasks:

- tighten progress and controls
- improve note readability
- refine failure and paused states

Acceptance criteria:

- player feels safe for customer-facing use

### Epic 9: Diagnostics

#### Slice 9.1

Goal:

- add integration diagnostics panel

Checks:

- route context resolver
- page context resolver
- TTS endpoint
- transcribe endpoint
- catalog API base URL
- asset reachability

Acceptance criteria:

- integration issues are diagnosable from inside Sherpa

#### Slice 9.2

Goal:

- add journey health summary

Checks:

- missing source language confirmation
- transcript/source mismatch
- missing original voice
- incomplete AI voice variants
- replay checkpoint warnings

Acceptance criteria:

- authors can tell whether a journey is publishable

### Epic 10: Docs and Launch Readiness

#### Slice 10.1

Goal:

- write product-facing documentation set

Docs:

- product overview
- integration guide
- author guide
- source vs AI voice guide
- page context vs step notes guide
- launch checklist

#### Slice 10.2

Goal:

- create launch gate checklist

Acceptance criteria:

- releases are evaluated against a written readiness bar

## Recommended PR Order

1. Source language confirmation + transcription contract
2. Derived language removal cleanup
3. Recorder flow UX polish
4. Recorder/playback E2E coverage
5. Studio workflow grouping
6. Service-mode contract and diagnostics
7. Module decomposition for recording
8. Module decomposition for playback
9. Remote-first draft model
10. Visual polish and launch docs

## Definition of Done For Each Slice

- user-visible behavior is explicit
- backward compatibility is either preserved or intentionally migrated
- tests cover the slice
- docs are updated when the contract changes
- failure states are surfaced, not hidden
