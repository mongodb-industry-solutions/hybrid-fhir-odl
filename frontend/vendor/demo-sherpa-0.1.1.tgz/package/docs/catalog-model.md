# Sherpa Catalog Model

Sherpa should treat the demo catalog as an editable knowledge base, not as a mirror of any one upstream source.

That matters because the relationship between public MongoDB Solution Library entries and real demo assets is not perfectly one-to-one:

- one Solution Library page may describe the closest public pattern for a private or customized demo
- one demo may have multiple relevant Solution Library pages
- some demos may have no Solution Library entry at all

The catalog therefore needs a canonical `demo` record that humans can edit, with many linked sources and assets around it.

## Principles

- The catalog must be useful on day one, even before a journey is recorded.
- A demo can be recommended without pretending Sherpa can guide it.
- Canonical demo records are editable by humans at all times.
- External sources are evidence, not truth.
- Controlled vocabularies should be curated but not closed forever.
- Business knowhow and technical knowhow should both be first-class.
- Logos, architecture diagrams, slide decks, transcripts, and GitHub docs should all be attachable resources.

## MongoDB Layout

Use the same MongoDB deployment as Leafy Hospital, with a dedicated database:

- database: `demo-sherpa`

Recommended collections:

- `demos`
- `demo_sources`
- `demo_assets`
- `demo_chunks`
- `taxonomies`
- `journeys`
- `journey_steps`
- `ingestion_jobs`

## Collection Roles

### `demos`

Editable canonical record for a real demo.

Suggested fields:

- `_id`
- `slug`
- `name`
- `shortDescription`
- `status`
- `owner`
- `portalUrl`
- `launchTargets`
- `launchUrl`
- `logoAssetId`
- `industries`
- `businessUseCases`
- `targetAudiences`
- `products`
- `mongodbCapabilities`
- `externalTechnologies`
- `architecturalPatterns`
- `businessKnowhow`
- `technicalKnowhow`
- `valueHighlights`
- `recommendedDurationMinutes`
- `hasGuidedJourney`
- `journeyCount`
- `resourceCoverage`
- `sourceConfidence`
- `createdAt`
- `updatedAt`

Important note:

- fields like `industries`, `products`, and `businessUseCases` should store canonical taxonomy ids plus optional display labels
- large narratives such as `businessKnowhow` and `technicalKnowhow` can store structured summaries plus long-form notes
- `launchTargets` should carry environment-aware demo destinations such as `local`, `staging`, and `production`
- keep `launchUrl` as a backward-compatible derived field during migration, resolving from `launchTargets[defaultEnvironment]` when available

### `demo_sources`

Tracks raw or curated source links related to a demo.

Suggested fields:

- `_id`
- `demoId`
- `sourceType`
- `relationType`
- `url`
- `title`
- `provider`
- `status`
- `confidence`
- `rawText`
- `extractedFields`
- `fetchedAt`
- `updatedAt`

Useful `sourceType` values:

- `solution-library`
- `github`
- `video`
- `powerpoint`
- `demo-portal`
- `solution-library-directory`
- `manual`

Useful `relationType` values:

- `primary-reference`
- `related-reference`
- `implementation`
- `recording`
- `presentation`
- `supporting-resource`

This is the key place where we model the fact that a Solution Library page may be only 95 percent related to a real demo.

### `demo_assets`

Binary or visual assets attached to a demo.

Suggested fields:

- `_id`
- `demoId`
- `sourceId`
- `assetKind`
- `title`
- `mimeType`
- `url`
- `storageKey`
- `thumbnailUrl`
- `language`
- `pageNumber`
- `caption`
- `ocrText`
- `metadata`
- `createdAt`

Useful `assetKind` values:

- `logo`
- `architecture-diagram`
- `slide-deck`
- `slide-image`
- `video`
- `screenshot`
- `thumbnail`
- `document`

Architecture diagrams should be stored here even when they were extracted from a Solution Library page or PowerPoint.

### `demo_chunks`

Chunked semantic retrieval units for vector search.

Suggested fields:

- `_id`
- `demoId`
- `sourceId`
- `assetId`
- `chunkType`
- `text`
- `embedding`
- `metadata`
- `createdAt`

Typical `chunkType` values:

- `business-summary`
- `technical-summary`
- `solution-overview`
- `github-readme`
- `transcript`
- `slide-text`
- `diagram-caption`
- `presenter-notes`

### `taxonomies`

Editable controlled vocabularies used for normalization and filtering.

Suggested fields:

- `_id`
- `taxonomy`
- `key`
- `label`
- `aliases`
- `status`
- `sortOrder`
- `metadata`
- `updatedAt`

This collection lets Sherpa evolve beyond hard-coded enums while still keeping a clean planner experience.

### `journeys`

Guided or partially guided presentations linked to a demo.

Suggested fields:

- `_id`
- `demoId`
- `name`
- `description`
- `guidanceAvailability`
- `languages`
- `estimatedDurationMinutes`
- `presenterNotes`
- `generatedNarrative`
- `createdAt`
- `updatedAt`

Useful `guidanceAvailability` values:

- `recorded`
- `scripted`
- `recommendation-only`

### `journey_steps`

Presenter and playback detail for a journey.

Suggested fields:

- `_id`
- `journeyId`
- `sequence`
- `name`
- `path`
- `primaryLanguage`
- `recordedLanguages`
- `estimatedDurationMs`
- `beforeMessage`
- `talkTrack`
- `whyMongo`
- `requiresManualAdvance`
- `manualAdvancePrompt`
- `timingNotes`
- `events`
- `audioClips`
- `voiceAssetId`
- `createdAt`
- `updatedAt`

Manual advance is important because Sherpa should never assume it can switch demos for the presenter.

### `ingestion_jobs`

Tracks intake submissions and asynchronous enrichment.

Suggested fields:

- `_id`
- `demoId`
- `submittedBy`
- `inputLinks`
- `pipelineStatus`
- `steps`
- `errors`
- `warnings`
- `candidateFields`
- `publishedAt`
- `createdAt`
- `updatedAt`

## Day-One Experience

Sherpa should be valuable before every journey is recorded.

Day-one planner behavior:

- recommend the best demo for a customer opportunity
- explain why it matches
- surface the best supporting resources
- tell the architect whether a guided journey exists
- link out to GitHub, Solution Library, portal pages, videos, slides, and diagrams

That means the catalog should distinguish between:

- `canRecommend`
- `canGuide`

Both can be true, but only `canRecommend` is required on day one.

## Ingestion Flow

### Intake UI

Minimal initial form:

- demo name
- demo portal link
- GitHub link
- video link
- PowerPoint link
- Solution Library link
- optional logo
- optional owner

### Automated enrichment

1. Fetch source pages and metadata.
2. Extract raw text from Solution Library, GitHub README docs, slide decks, and transcripts.
3. Detect candidate taxonomy matches for industry, business use case, product, audience, and architecture pattern.
4. Generate structured summaries for business knowhow and technical knowhow.
5. Extract visual assets such as logos and architecture diagrams where possible.
6. Create vector chunks for semantic retrieval.
7. Save a reviewable candidate record into `ingestion_jobs`.

### Human review

Before publishing a demo into the main catalog, a reviewer should be able to:

- merge or split source relationships
- override taxonomy values
- edit descriptions and knowhow
- choose the correct logo
- promote extracted diagrams
- mark the demo as recommendation-only or guided

## Solution Library Bootstrap

The public MongoDB Solutions Library is a strong first pass because the detail pages commonly expose:

- name
- short description
- use cases
- industries
- products
- solution overview
- GitHub link
- architecture figures or supporting visuals

These pages should populate candidate data, but not overwrite the canonical demo record without review.

## Taxonomy Strategy

Do not overload one field with multiple concepts.

Recommended separations:

- `industries`: healthcare, financial services, retail, and so on
- `businessUseCases`: interoperability, customer 360, clinical trials, fraud detection, recommendations, and so on
- `products`: MongoDB Atlas, Atlas Search, Atlas Vector Search, Atlas Stream Processing, and so on
- `mongodbCapabilities`: Aggregation Framework, Change Streams, Time Series, Geospatial, and so on
- `externalTechnologies`: OpenAI, Voyage AI, Kafka, Snowflake, AWS, Azure, and so on
- `architecturalPatterns`: RAG, real-time analytics, event-driven integration, search, sync and migration, and so on

This gives Sherpa much cleaner planner results than a single overloaded `product` field.

## Diagram Capture

When extracting architecture blueprints, keep both the image and the context around it.

Recommended metadata for diagrams:

- `caption`
- `sourceUrl`
- `surroundingText`
- `ocrText`
- `diagramType`
- `productsShown`
- `externalTechnologiesShown`

This allows the copilot to answer questions about an architecture diagram later instead of treating it as a dead image.

## Hybrid Retrieval For Copilot

Sherpa should use a hybrid retrieval approach:

1. Apply structured filters from canonical metadata.
2. Run vector search over `demo_chunks`.
3. Retrieve linked resources and diagrams.
4. Ask a reasoning model to assemble the best guided journey or recommendation set.
5. Return citations and links back to the underlying resources.

This works for both:

- planners used by sales or solution architects
- presenter-side Sherpa guidance during demo delivery
