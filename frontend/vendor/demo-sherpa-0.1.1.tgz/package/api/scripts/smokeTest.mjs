import dotenv from "dotenv";

dotenv.config({
  path: new URL("../.env", import.meta.url),
});

const baseUrl = process.env.SHERPA_API_BASE_URL || `http://localhost:${process.env.PORT || "9091"}`;

const checks = [
  {
    name: "health",
    request: () => fetch(`${baseUrl}/sherpa/catalog/health`),
  },
  {
    name: "demos",
    request: () => fetch(`${baseUrl}/sherpa/catalog/demos?limit=3`),
  },
  {
    name: "taxonomies",
    request: () => fetch(`${baseUrl}/sherpa/catalog/taxonomies?taxonomy=industries`),
  },
  {
    name: "semantic-root",
    request: () => fetch(`${baseUrl}/`),
  },
];

for (const check of checks) {
  const response = await check.request();
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    console.error(`Smoke check failed: ${check.name}`);
    console.error(JSON.stringify(payload, null, 2));
    process.exit(1);
  }
  console.log(`${check.name}: ok`);
}

console.log("Sherpa API smoke test passed.");
