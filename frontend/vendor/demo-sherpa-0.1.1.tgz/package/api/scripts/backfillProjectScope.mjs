import dotenv from "dotenv";
import { MongoClient } from "mongodb";

dotenv.config({
  path: new URL("../.env", import.meta.url),
});

const env = (name, fallback = "") => process.env[name] || fallback;

const parseArgs = (argv) => {
  const args = {};
  for (let index = 2; index < argv.length; index += 1) {
    const token = String(argv[index] || "").trim();
    if (!token.startsWith("--")) continue;
    const [rawKey, rawValue] = token.slice(2).split("=");
    const key = String(rawKey || "").trim();
    if (!key) continue;
    if (rawValue !== undefined) {
      args[key] = rawValue;
      continue;
    }
    const next = String(argv[index + 1] || "").trim();
    if (next && !next.startsWith("--")) {
      args[key] = next;
      index += 1;
    } else {
      args[key] = "true";
    }
  }
  return args;
};

const args = parseArgs(process.argv);
const projectId = String(args.projectId || env("SHERPA_BACKFILL_PROJECT_ID", "")).trim();
const projectSlug = String(args.projectSlug || env("SHERPA_BACKFILL_PROJECT_SLUG", "")).trim();
const projectName = String(args.projectName || env("SHERPA_BACKFILL_PROJECT_NAME", "")).trim();

if (!env("MONGODB_CONNECTION_STRING")) {
  throw new Error("Missing required environment variable: MONGODB_CONNECTION_STRING");
}

if (!projectSlug || !projectName) {
  throw new Error("Provide --projectSlug and --projectName (or SHERPA_BACKFILL_PROJECT_SLUG / SHERPA_BACKFILL_PROJECT_NAME).");
}

const client = new MongoClient(env("MONGODB_CONNECTION_STRING"));
await client.connect();

const db = client.db(env("SHERPA_DB", "demo-sherpa"));
const demos = db.collection(env("SHERPA_DEMOS_COLLECTION", "demos"));
const journeys = db.collection(env("SHERPA_JOURNEYS_COLLECTION", "journeys"));

const demoFilter = {
  $or: [
    { projectSlug: { $exists: false } },
    { projectSlug: "" },
    { projectSlug: null },
  ],
};
const journeyFilter = {
  $or: [
    { "context.projectSlug": { $exists: false } },
    { "context.projectSlug": "" },
    { "context.projectSlug": null },
  ],
};

const now = new Date();
const [demoResult, journeyResult] = await Promise.all([
  demos.updateMany(demoFilter, {
    $set: {
      ...(projectId ? { projectId } : {}),
      projectSlug,
      projectName,
      updatedAt: now,
    },
  }),
  journeys.updateMany(journeyFilter, {
    $set: {
      ...(projectId ? { "context.projectId": projectId } : {}),
      "context.projectSlug": projectSlug,
      "context.projectName": projectName,
      updatedAt: now.toISOString(),
    },
  }),
]);

console.log(JSON.stringify({
  projectId,
  projectSlug,
  projectName,
  demosMatched: demoResult.matchedCount,
  demosModified: demoResult.modifiedCount,
  journeysMatched: journeyResult.matchedCount,
  journeysModified: journeyResult.modifiedCount,
}, null, 2));

await client.close();
