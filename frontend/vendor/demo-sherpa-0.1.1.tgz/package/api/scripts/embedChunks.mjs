import dotenv from "dotenv";
import { MongoClient } from "mongodb";

import { embedCatalogChunks } from "../lib/catalogServices.mjs";

dotenv.config({
  path: new URL("../.env", import.meta.url),
});

if (!process.env.MONGODB_CONNECTION_STRING) {
  throw new Error("Missing required environment variable: MONGODB_CONNECTION_STRING");
}

const client = new MongoClient(process.env.MONGODB_CONNECTION_STRING);
await client.connect();

const db = client.db(process.env.SHERPA_DB || "demo-sherpa");
const collections = {
  demos: db.collection(process.env.SHERPA_DEMOS_COLLECTION || "demos"),
  sources: db.collection(process.env.SHERPA_SOURCES_COLLECTION || "demo_sources"),
  assets: db.collection(process.env.SHERPA_ASSETS_COLLECTION || "demo_assets"),
  chunks: db.collection(process.env.SHERPA_CHUNKS_COLLECTION || "demo_chunks"),
  taxonomies: db.collection(process.env.SHERPA_TAXONOMIES_COLLECTION || "taxonomies"),
  journeys: db.collection(process.env.SHERPA_JOURNEYS_COLLECTION || "journeys"),
  journeySteps: db.collection(process.env.SHERPA_JOURNEY_STEPS_COLLECTION || "journey_steps"),
  ingestionJobs: db.collection(process.env.SHERPA_INGESTION_JOBS_COLLECTION || "ingestion_jobs"),
};

const limit = Number.parseInt(process.env.SHERPA_EMBED_LIMIT || "500", 10) || 500;
const force = String(process.env.SHERPA_EMBED_FORCE || "false").trim().toLowerCase() === "true";

const result = await embedCatalogChunks(collections, { limit, force });
console.log(JSON.stringify(result, null, 2));

await client.close();
